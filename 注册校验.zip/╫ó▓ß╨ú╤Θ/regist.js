function checkUsername(){
	var username = document.getElementById("username");
	var username1 = username.value;
	
	var len = username1.length;
	var usernameSpan =document.getElementById("usernameSpan");
	if(len<8 || len>14){
		usernameSpan.innerHTML= "<font color='red'> 请输入合法的用户名</font>";
	}else{
		usernameSpan.innerHTML= "<font color='blue'>√</font>";
	}
}
function checkPassword(){
		var password = document.getElementById("password");
	var password1 = password.value;
	
	var len = password1.length;
	var passwordSpan =document.getElementById("passwordSpan");
	if(len<8 || len>10){
		passwordSpan.innerHTML= "<font color='red'> 请输入合法的密码</font>";
	}else{
		passwordSpan.innerHTML= "<font color='blue'>√</font>";
	}
}
