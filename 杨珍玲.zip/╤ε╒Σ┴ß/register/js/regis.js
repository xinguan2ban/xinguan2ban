function checkusername(){
	var user=document.getElementById("use").value;
	var usernamespan=document.getElementById("usernamespan");
	if(user.length<8 || user.length>14){
		usernamespan.innerHTML="<font color='red'>用户名输入错误</font>";
		
	}else{
		usernamespan.innerHTML="<b>√</b>";
	}
	
}
function checkpassword(){
	var psd=document.getElementById("psd").value;
	var passwordspan=document.getElementById("passwordspan").value;
	
	
}
