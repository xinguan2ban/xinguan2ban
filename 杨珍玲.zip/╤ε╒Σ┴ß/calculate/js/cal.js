
function count(){
     var a = document.getElementById("txt1").value;
     var b = document.getElementById("txt2").value;
     var c = document.getElementById("select").value;
     a = parseFloat(a);
     b = parseFloat(b);
     
    switch(c){
         case "+":
         document.getElementById("txt3").value=parseInt(a)+parseInt(b);
         break;
        case "-":
        document.getElementById("txt3").value=parseInt(a)-parseInt(b);
        break;
        case "*":
        document.getElementById("txt3").value=parseInt(a)*parseInt(b);
         break;
         case "/":
         document.getElementById("txt3").value=parseInt(a)/parseInt(b);
         break;
    }
  }