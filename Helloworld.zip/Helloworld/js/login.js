function login() {
	// console.info("点击了登录");
	var userName = $("#uName").val();
	// console.info(userName)
	var userPass = $("#uPass").val();
	// console.info(userPass);
	if (userName == "" || userName == null) {
		alert("用户名不能为空");
		return false;
	} else if (userPass == "" || userPass == null) {
		alert("密码不能为空");
		return false;
	} else {
		return true;
	}
}