function checkuser(){
	var ID=document.getElementById("username").value;
	var userSpan=document.getElementById('userSpan');
	var len=ID.length;
	if(len!=11){
		userSpan.innerHTML="<font color='red' size='4'>请输入正确的账号</font>";
	}
	
	
}
function checkpass(){
	var passwd1=document.getElementById("passwd1").value;
	var passwd2=document.getElementById("passwd2").value;
	var passSpan1=document.getElementById('passSpan1');
	var passSpan2=document.getElementById('passSpan2');
	if((passwd1.length==0)||(passwd2.length==0)){
		passSpan1.innerHTML="<font color='red' size='4'>不能为空值</font>"	;
	}else{
		if((passwd1!=passwd2)){
		passSpan2.innerHTML="<font color='red' size='4'>两次密码不一致</font>"	;
	}else{
		passSpan1.innerHTML="<font color='red'>√</font>"	;
		passSpan2.innerHTML="<font color='red'>√</font>"	;
	}
	}
}

function Email(){
	var emails=document.getElementById("emails").value;
	var emailSpan=document.getElementById('emailSpan');
	
	if(emails.length==0){
		emailSpan.innerHTML="<font color='red' size='4'>不能为空</font>"	;
	}
	
}

function clickzc(){
	
	
	var uname=document.getElementById("uname").value;
	var gen1=document.getElementById("gen1").value;
	var gen2=document.getElementById("gen2").value;
	
  var verify=document.getElementById('verify').value;
  var code=document.getElementById('code').value;
  
	document.getElementById('code').value=Math.floor(Math.random()*8999)+1000;
		if(verify!=code){
		alert('验证码不正确')
	}
	
}