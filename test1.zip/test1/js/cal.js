
function clickme(){
    str1=Number(document.getElementById("num1").value);
    str2=Number(document.getElementById("num2").value);
    comp=document.getElementById("cal").value;
    
    var zhengze = /^[0-9]{1,}$/;
   
    if(!zhengze.test(num1.value)){
        
        alert('只能输入整数或者数字');
      
        return false;
    }else if(!zhengze.test(num2.value)){
        
        alert('只能输入整数或者数字');
        return false;
    }
    
    
    var result;
    switch(comp) {
      case "+":
        comp=str1+str2;
        break;
      case "-":
        comp=str1-str2;
        break;
      case "*":
        comp=str1*str2;
        break;
      case "/":
        if(str2==0){
          alert("除数不能为0！");
          comp='';
        }else{
          comp=str1/str2;
        }
        break;
    }
    document.getElementById("btn").value=comp;
  }