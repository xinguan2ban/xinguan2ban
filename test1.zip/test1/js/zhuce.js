function checkuserName(){
	var usernameEln=document.getElementById("userName");
	var usernameVal=usernameEln.value;
	var len=usernameVal.length;
	var usernameSpan=document.getElementById("userNameSpan");
		if(len<8 || len>14){
			usernameSpan.innerHTML="<font color='red'>用户名不合法</font>";
		}else{
			usernameSpan.innerHTML="<font color='green'>√</font>";
		}
		return false;
	}



