-- MySQL dump 10.13  Distrib 5.5.40, for Win64 (x86)
--
-- Host: localhost    Database: gradesystem
-- ------------------------------------------------------
-- Server version	5.5.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `apassword` varchar(20) DEFAULT NULL,
  `aname` varchar(20) DEFAULT NULL,
  `asex` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'123456','小明','男'),(2,'123','向华杰','男');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) DEFAULT NULL,
  `ctime` varchar(20) DEFAULT NULL,
  `ctype` varchar(20) DEFAULT NULL,
  `cteacher` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'计算机基础','64','必修','小静'),(2,'专业英语','32','必修','小波'),(3,'java','140','','赵雷'),(4,'数据挖掘','64','必修','小方'),(5,'IT新技术','64','必修','小齐'),(6,'c语言','64','必修','小徐'),(99,'11','11',NULL,'11');
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `function`
--

DROP TABLE IF EXISTS `function`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function` (
  `fid` int(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) DEFAULT NULL,
  `fstate` varchar(20) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `furl` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `function`
--

LOCK TABLES `function` WRITE;
/*!40000 ALTER TABLE `function` DISABLE KEYS */;
INSERT INTO `function` VALUES (1,'教务信息管理','closed',-1,NULL),(2,'教师信息管理','open',1,'tm.jsp'),(3,'课程信息管理','open',1,'cm.jsp'),(4,'学生信息管理','open',1,'sm.jsp');
/*!40000 ALTER TABLE `function` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionadm`
--

DROP TABLE IF EXISTS `functionadm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functionadm` (
  `fid` int(20) NOT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `fstate` varchar(20) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `furl` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionadm`
--

LOCK TABLES `functionadm` WRITE;
/*!40000 ALTER TABLE `functionadm` DISABLE KEYS */;
INSERT INTO `functionadm` VALUES (1,'教务系统管理','closed',-1,NULL),(2,'教师信息管理','open',1,'admteacher.jsp'),(3,'学生信息管理','open',1,'admstudent.jsp'),(4,'课程信息查询','open',1,'admcourse.jsp'),(5,'成绩信息查询','open',1,'admgrade.jsp'),(6,'个人信息查询','open',1,'admmyself.jsp');
/*!40000 ALTER TABLE `functionadm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functionstu`
--

DROP TABLE IF EXISTS `functionstu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functionstu` (
  `fid` int(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) DEFAULT NULL,
  `fstate` varchar(20) DEFAULT NULL,
  `parentId` int(20) DEFAULT NULL,
  `furl` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functionstu`
--

LOCK TABLES `functionstu` WRITE;
/*!40000 ALTER TABLE `functionstu` DISABLE KEYS */;
INSERT INTO `functionstu` VALUES (1,'教务信息查询','closed',-1,NULL),(2,'课程信息查询','open',1,'stucourse.jsp'),(3,'成绩信息查询','open',1,'stugrade.jsp'),(4,'个人信息查询','open',1,'stumyself.jsp');
/*!40000 ALTER TABLE `functionstu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `functiontea`
--

DROP TABLE IF EXISTS `functiontea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `functiontea` (
  `fid` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `fstate` varchar(255) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `furl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `functiontea`
--

LOCK TABLES `functiontea` WRITE;
/*!40000 ALTER TABLE `functiontea` DISABLE KEYS */;
INSERT INTO `functiontea` VALUES (1,'教务系统管理','closed',-1,NULL),(2,'学生成绩录入','closed',-1,NULL),(3,'个人信息查询','open',1,'teamyself.jsp'),(4,'15级1班','open',2,'teastudent1.jsp'),(5,'15级2班','open',2,'teastudent2.jsp');
/*!40000 ALTER TABLE `functiontea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade`
--

DROP TABLE IF EXISTS `grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grade` (
  `gid` int(10) NOT NULL,
  `sid` int(20) DEFAULT NULL,
  `sname` varchar(20) DEFAULT NULL,
  `cid` int(20) DEFAULT NULL,
  `cname` varchar(20) DEFAULT NULL,
  `sclass` varchar(20) DEFAULT NULL,
  `smajor` varchar(20) DEFAULT NULL,
  `cteacher` varchar(20) DEFAULT NULL,
  `score` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `gradecid` (`cid`),
  KEY `gradesid` (`sid`),
  CONSTRAINT `gradecid` FOREIGN KEY (`cid`) REFERENCES `course` (`cid`) ON DELETE CASCADE,
  CONSTRAINT `gradesid` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grade`
--

LOCK TABLES `grade` WRITE;
/*!40000 ALTER TABLE `grade` DISABLE KEYS */;
INSERT INTO `grade` VALUES (1,201605,'向华杰',1,'计算机基础','信管2班','信管','向华','100');
/*!40000 ALTER TABLE `grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `sid` int(20) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) DEFAULT NULL,
  `ssex` varchar(20) DEFAULT NULL,
  `sclass` varchar(20) DEFAULT NULL,
  `smajor` varchar(20) DEFAULT NULL,
  `spassword` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=20160106 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (201605,'向华杰','男','16级2班','信管','123456'),(201618,'李健铭','男','16级2班','我男神','6547122'),(201619,'苟奕丹','女','16级2班','信管','32185'),(201622,'杨松霖','男','16级2班','信管','654'),(201626,'张艺凡','女','16级2班','信管','1111111'),(201627,'冬梅','女','16级2班','信管','12345678'),(201633,'杨欣','女','16级2班','信管','12345'),(201636,'刘思琪','女','16级2班','信管','123321'),(201646,'喻磊','男','16级2班','唱跳rap','6543213'),(201691,'蔡徐坤','男','16级2班','打篮球','99999'),(201692,'谢广坤','男','16级2班','打蔡徐坤','654987'),(201697,'菜虚坤','男','16级2班','吃蔡徐坤','654213'),(2016011,'小明','男','16级1班','计本','3213213'),(2016022,'小红','男','16级1班','计本','65465'),(2016033,'小绿','女','16级1班','计本','9999');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher` (
  `tid` int(10) NOT NULL AUTO_INCREMENT,
  `tname` varchar(20) DEFAULT NULL,
  `tsex` varchar(20) DEFAULT NULL,
  `tpassword` varchar(20) DEFAULT NULL,
  `ttocourse` varchar(20) DEFAULT NULL,
  `ttodepartment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher`
--

LOCK TABLES `teacher` WRITE;
/*!40000 ALTER TABLE `teacher` DISABLE KEYS */;
INSERT INTO `teacher` VALUES (1,'曾鹏','男','12345','中软培训','信管'),(3,'赵雷','男','123','java','信管'),(4,'张敏','男','123','生日partty','信管'),(5,'田冬梅','女','123','JAVA编程','信管'),(6,'刘诗琪','女','123','IT新技术','信管');
/*!40000 ALTER TABLE `teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yixuancourse`
--

DROP TABLE IF EXISTS `yixuancourse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yixuancourse` (
  `yid` int(20) NOT NULL,
  `cid` int(20) DEFAULT NULL,
  `cname` varchar(20) DEFAULT NULL,
  `sid` int(20) DEFAULT NULL,
  `sname` varchar(20) DEFAULT NULL,
  `sclass` varchar(20) DEFAULT NULL,
  `smajor` varchar(20) DEFAULT NULL,
  `ctype` varchar(20) DEFAULT NULL,
  `cteacher` varchar(20) DEFAULT NULL,
  `ystate` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`yid`),
  KEY `yixuancoursecid` (`cid`),
  KEY `yixuancoursesid` (`sid`),
  CONSTRAINT `yixuancoursecid` FOREIGN KEY (`cid`) REFERENCES `course` (`cid`) ON DELETE CASCADE,
  CONSTRAINT `yixuancoursesid` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yixuancourse`
--

LOCK TABLES `yixuancourse` WRITE;
/*!40000 ALTER TABLE `yixuancourse` DISABLE KEYS */;
/*!40000 ALTER TABLE `yixuancourse` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-30  8:32:46
