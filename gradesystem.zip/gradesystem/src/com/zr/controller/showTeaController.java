package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showTeaService;
import com.zr.service.impl.showTeaServiceImpl;

import net.sf.json.JSONArray;

public class showTeaController extends HttpServlet{
	showTeaService sts = new showTeaServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		   JSONArray   js =   sts.showFuncs(-1);
		   //System.out.println(js);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(js.toString());
	}
	
}
