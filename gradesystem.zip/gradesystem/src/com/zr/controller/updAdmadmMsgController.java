package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.ShowAdmService;
import com.zr.service.impl.ShowAdmServiceImpl;

public class updAdmadmMsgController extends HttpServlet{
	ShowAdmService sas = new ShowAdmServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf8");//接收的数据的格式
		   resp.setCharacterEncoding("utf8");//输出数据的
		  //1.接受更改的信息  -》调用 service --》调用dao层  
		   String  aid =req.getParameter("aid");
		   String  aname=req.getParameter("aname");
		   String  asex =req.getParameter("asex");
		   String  apassword= req.getParameter("apassword");
		   String up = sas.updateadmin(aid, aname,apassword, asex);
		   System.out.println(up);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(up.toString());
	}
}
