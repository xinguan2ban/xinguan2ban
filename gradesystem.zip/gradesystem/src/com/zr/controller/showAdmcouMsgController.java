package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmcouMsgService;
import com.zr.service.impl.showAdmcouMsgServiceImpl;

import net.sf.json.JSONObject;

public class showAdmcouMsgController extends HttpServlet{
	showAdmcouMsgService sat = new showAdmcouMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	     req.setCharacterEncoding("utf-8");
		 resp.setCharacterEncoding("utf-8");
		 int  page =  Integer.parseInt(req.getParameter("page")) ;
		 int  size =  Integer.parseInt(req.getParameter("rows")) ;
		 JSONObject  js = sat.showcmPersonMsg(page, size);
		 PrintWriter  pw = resp.getWriter();
		 pw.write(js.toString());
	}
	
}
