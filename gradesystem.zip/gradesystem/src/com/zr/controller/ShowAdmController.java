package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.ShowAdmService;
import com.zr.service.impl.ShowAdmServiceImpl;

import net.sf.json.JSONArray;

public class ShowAdmController extends HttpServlet{
	ShowAdmService sas = new ShowAdmServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	 @Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			req.setCharacterEncoding("utf-8");
			resp.setCharacterEncoding("utf-8");
			   JSONArray   js =   sas.showFuncs(-1);
			   //System.out.println(js);
			   PrintWriter  pw = resp.getWriter();
			   pw.write(js.toString());
	}
}
