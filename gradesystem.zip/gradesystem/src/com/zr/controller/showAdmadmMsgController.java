package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.ShowAdmService;
import com.zr.service.impl.ShowAdmServiceImpl;

import net.sf.json.JSONObject;

public class showAdmadmMsgController extends HttpServlet{
	ShowAdmService sas = new ShowAdmServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	     req.setCharacterEncoding("utf-8");
		 resp.setCharacterEncoding("utf-8");
		 int  page =  Integer.parseInt(req.getParameter("page")) ;
		 int  size =  Integer.parseInt(req.getParameter("rows")) ;
		 String account = (String) req.getSession().getAttribute("account");
		 JSONObject  js = sas.showcmPersonMsg(page,size,account);
		 PrintWriter  pw = resp.getWriter();
		 pw.write(js.toString());
	}
	
}
