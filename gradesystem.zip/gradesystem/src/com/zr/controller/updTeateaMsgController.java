package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showTeaService;
import com.zr.service.impl.showTeaServiceImpl;

public class updTeateaMsgController extends HttpServlet{
	showTeaService sts = new showTeaServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf8");//接收的数据的格式
		   resp.setCharacterEncoding("utf8");//输出数据的
		  //1.接受更改的信息  -》调用 service --》调用dao层  
		   String  tid =req.getParameter("tid");
		   String  tname=req.getParameter("tname");
		   String  tsex =req.getParameter("tsex");
		   String  tpassword= req.getParameter("tpassword");
		   String  ttocourse=req.getParameter("ttocourse");
		   String  ttodepartment=req.getParameter("ttodepartment");
		   String up = sts.updateteacher(tid, tname, tsex, tpassword, ttocourse, ttodepartment);
		   System.out.println(up);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(up.toString());
	}
}
