package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showTeaService;
import com.zr.service.impl.showTeaServiceImpl;

import net.sf.json.JSONObject;

public class showTeagraaMsgController extends HttpServlet{
	showTeaService sts = new showTeaServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	     req.setCharacterEncoding("utf-8");
		 resp.setCharacterEncoding("utf-8");
		 int  page =  Integer.parseInt(req.getParameter("page")) ;
		 int  size =  Integer.parseInt(req.getParameter("rows")) ;
		 String ttodepartment = (String) req.getSession().getAttribute("ttodepartment");
		 String name = (String) req.getSession().getAttribute("name");
		 System.out.println(ttodepartment);
		 JSONObject  js = sts.showTeagraaMsg(page,size,ttodepartment,name);
		 PrintWriter  pw = resp.getWriter();
		 pw.write(js.toString());
	}
	
}
