package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.management.modelmbean.DescriptorSupport;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmcouMsgService;
import com.zr.service.impl.showAdmcouMsgServiceImpl;

public class updAdmcouMsgController extends HttpServlet{
	showAdmcouMsgService sat = new showAdmcouMsgServiceImpl();
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}

	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf8");//接收的数据的格式
		   resp.setCharacterEncoding("utf8");//输出数据的
		  //1.接受更改的信息  -》调用 service --》调用dao层  
		   String  cid =req.getParameter("cid");
		   String  cname=req.getParameter("cname");
		   System.out.println(cname);
		   String  ctime =req.getParameter("ctime");
		   System.out.println(ctime);
		   String  ctype= req.getParameter("ctype");
		   String  cteacher=req.getParameter("cteacher");
		   String up = sat.updatecourse(cid, cname, ctime, ctype, cteacher);
		   System.out.println(up);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(up.toString());
		}
	
}
