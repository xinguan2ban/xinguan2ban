package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmteaMsgService;
import com.zr.service.impl.ShowAdmteaMsgServiceImpl;

import net.sf.json.JSONObject;

public class showAdmteaMsgController extends HttpServlet{
	showAdmteaMsgService ast = new ShowAdmteaMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 int  page =  Integer.parseInt(req.getParameter("page")) ;
		 int  size =  Integer.parseInt(req.getParameter("rows")) ;
		 JSONObject  js = ast.showcmPersonMsg(page, size);
	     req.setCharacterEncoding("utf-8");
		 resp.setCharacterEncoding("utf-8");
		 PrintWriter  pw = resp.getWriter();
		 pw.write(js.toString());
	}
}
