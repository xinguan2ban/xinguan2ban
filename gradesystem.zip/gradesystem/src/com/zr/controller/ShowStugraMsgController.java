package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.zr.service.ShowStugraMsgService;
import com.zr.service.impl.ShowStugraMsgServiceImpl;
import net.sf.json.JSONObject;

public class ShowStugraMsgController extends HttpServlet{
	ShowStugraMsgService ss = new ShowStugraMsgServiceImpl();
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 	req.setCharacterEncoding("utf-8");
		 	resp.setCharacterEncoding("utf-8");
		  String account = (String) req.getSession().getAttribute("account");
		  System.out.println(account);
		  int  page =  Integer.parseInt(req.getParameter("page")) ;
		  int  size =  Integer.parseInt(req.getParameter("rows")) ;
		  JSONObject  js = ss.showgradePersonMsg(page, size,account);
		  resp.setCharacterEncoding("utf8");
		  PrintWriter  pw = resp.getWriter();
		  pw.write(js.toString());
		}
}
