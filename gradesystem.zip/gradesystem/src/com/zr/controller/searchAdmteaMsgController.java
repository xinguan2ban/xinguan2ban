package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmteaMsgService;
import com.zr.service.impl.ShowAdmteaMsgServiceImpl;

import net.sf.json.JSONObject;

public class searchAdmteaMsgController extends HttpServlet{
	showAdmteaMsgService sat = new ShowAdmteaMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		String tid = req.getParameter("tid");
		System.out.println(tid);
		String ttocourse = req.getParameter("ttocourse");
		System.out.println(ttocourse);
		String ttodepartment = req.getParameter("ttodepartment");
		System.out.println(ttodepartment);
	    JSONObject js = sat.searchAdmteaMsg(tid, ttocourse, ttodepartment);
		PrintWriter  pw = resp.getWriter();
		pw.write(js.toString());
	}
	
}
