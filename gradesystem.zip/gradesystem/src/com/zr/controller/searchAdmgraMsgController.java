package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.zr.service.showAdmgraMsgService;
import com.zr.service.impl.showAdmgraMsgServiceImpl;

import net.sf.json.JSONObject;

public class searchAdmgraMsgController extends HttpServlet{
	showAdmgraMsgService sat = new showAdmgraMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		String sname = req.getParameter("sname");
		String cname = req.getParameter("cname");
		System.out.println(cname);
		String smajor = req.getParameter("smajor");
		System.out.println(smajor);
	    JSONObject js = sat.searchAdmgraMsg(sname, cname, smajor);
		PrintWriter  pw = resp.getWriter();
		pw.write(js.toString());
	}
	
}
