package com.zr.controller;

import java.awt.image.SampleModel;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmteaMsgService;
import com.zr.service.impl.ShowAdmteaMsgServiceImpl;

import net.sf.json.JSONObject;

public class validateTidController extends HttpServlet{
	showAdmteaMsgService sam = new ShowAdmteaMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  String tid = req.getParameter("tid");//得到index传过来的uname
		  System.out.println(req.getParameter("tid"));
		  boolean  flag  = sam.validateTidService(tid);//调用了一个validateService 方法  方返回turn or false
		  PrintWriter   pw = resp.getWriter();
		  JSONObject  msg = new JSONObject();
		  if(flag){
			  msg.put("remgs", 1);
		  }else{
			  msg.put("remgs", 0);
		  }
		  pw.write(msg.toString());
	}
	
}
