package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmgraMsgService;
import com.zr.service.impl.showAdmgraMsgServiceImpl;

public class addAdmgraMsgController extends HttpServlet{
	showAdmgraMsgService sat = new showAdmgraMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf8");//接收的数据的格式
		   resp.setCharacterEncoding("utf8");//输出数据的
		  //1.接受更改的信息  -》调用 service --》调用dao层  
		   String  gid =req.getParameter("gid");
		   String  sid=req.getParameter("sid");
		   String  sname =req.getParameter("sname");
		   String  cid= req.getParameter("cid");
		   String  cname= req.getParameter("cname");
		   String  sclass= req.getParameter("sclass");
		   String  smajor= req.getParameter("smajor");
		   String  cteacher=req.getParameter("cteacher");
		   String  score= req.getParameter("score");
		   String  up = sat.insertgrade(gid, sid, sname, cid, cname, sclass, smajor, cteacher, score);
		   System.out.println(up);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(up.toString());
	}
	
	
}
