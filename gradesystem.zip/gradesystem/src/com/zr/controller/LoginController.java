package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.LoginService;
import com.zr.service.impl.LoginServiceImpl;

import net.sf.json.JSON;
import net.sf.json.JSONObject;

public class LoginController extends HttpServlet{
	LoginService ls = new LoginServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		//获取存储到服务器的用户输入的信息
		String account = req.getParameter("account");
		String password = req.getParameter("password");
		String redioname = req.getParameter("radioname");
		String ttodepartment = null;
		if (redioname.equals("教师")) {
			 ttodepartment  = ls.validatettodepartment(account);
		}
		System.out.println("ttodepartment"+ttodepartment);
		String name = ls.validateNa(redioname,account);
		req.getSession().setAttribute("name", name);
		req.getSession().setAttribute("account", account);
		req.getSession().setAttribute("ttodepartment", ttodepartment);
		//用户名以及用户类型所对应的密码
		//String password = ls.validatePws(redio,account);
		//判断用户是否存在
		boolean bpwd = ls.validatePws(redioname, account, password);
		String bpwdStr = String.valueOf(bpwd);
		JSONObject pwdbljsonobject = new JSONObject();
		boolean bpacc = ls.validateAccount(redioname, account);
		String bpaccStr =String.valueOf(bpacc);
		//将两个json对象合并成一个
		pwdbljsonobject.put("pwd", bpwdStr);
		pwdbljsonobject.put("blaccount", bpaccStr);
//		String pwdblstring = pwdbljsonobject.toString();
		System.out.println(pwdbljsonobject);
		PrintWriter pw = resp.getWriter();
//		pw.write(pwdbljsonobject.toString());
		pw.print(pwdbljsonobject);
		pw.close();		
	}
	
}
