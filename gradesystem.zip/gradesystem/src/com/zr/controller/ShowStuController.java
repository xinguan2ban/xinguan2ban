package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.ShowStuService;
import com.zr.service.impl.ShowStuServiceImpl;

import net.sf.json.JSONArray;

public class ShowStuController extends HttpServlet{
	ShowStuService sss = new ShowStuServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		   JSONArray   js =   sss.showFuncs(-1);
		   //System.out.println(js);
		   PrintWriter  pw = resp.getWriter();
		   pw.write(js.toString());
	}
	
}
