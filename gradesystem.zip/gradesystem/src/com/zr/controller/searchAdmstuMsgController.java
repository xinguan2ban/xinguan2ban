package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.zr.service.showAdmstuMsgService;
import com.zr.service.impl.ShowAdmstuMsgServiceImpl;
import net.sf.json.JSONObject;

public class searchAdmstuMsgController extends HttpServlet{
	showAdmstuMsgService sat = new ShowAdmstuMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		String sid = req.getParameter("sid");
		System.out.println(sid);
		String sclass = req.getParameter("sclass");
		System.out.println(sclass);
		String smajor = req.getParameter("smajor");
		System.out.println(smajor);
	    JSONObject js = sat.searchAdmstuMsg(sid, sclass, smajor);
		PrintWriter  pw = resp.getWriter();
		pw.write(js.toString());
	}
}
