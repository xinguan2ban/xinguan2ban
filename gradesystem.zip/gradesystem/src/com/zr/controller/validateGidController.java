package com.zr.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.zr.service.showAdmgraMsgService;
import com.zr.service.impl.showAdmgraMsgServiceImpl;

import net.sf.json.JSONObject;

public class validateGidController extends HttpServlet{
	showAdmgraMsgService sat = new showAdmgraMsgServiceImpl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  String gid = req.getParameter("gid");//得到index传过来的uname
		  System.out.println("8023"+gid);
		  boolean  flag  = sat.validateGidService(gid);//调用了一个validateService 方法  方返回turn or false
		  PrintWriter   pw = resp.getWriter();
		  JSONObject  msg = new JSONObject();
		  if(flag){
			  msg.put("remgs", 1);
		  }else{
			  msg.put("remgs", 0);
		  }
		  pw.write(msg.toString());
		  System.out.println(msg);
	}
	
}
