package com.zr.model;

public class teacher {
	private int tid;
	private String tname;
	private String tsex;
	private String tpassword;
	private String ttocourse;
	private String ttodepartment;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	
	public String getTsex() {
		return tsex;
	}
	public void setTsex(String tsex) {
		this.tsex = tsex;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTpassword() {
		return tpassword;
	}
	public void setTpassword(String tpassword) {
		this.tpassword = tpassword;
	}
	public String getTtocourse() {
		return ttocourse;
	}
	public void setTtocourse(String ttocourse) {
		this.ttocourse = ttocourse;
	}
	public String getTtodepartment() {
		return ttodepartment;
	}
	public void setTtodepartment(String ttodepartment) {
		this.ttodepartment = ttodepartment;
	}

	
}
