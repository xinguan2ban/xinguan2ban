package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.dao.showAdmcouMsgDao;
import com.zr.model.course;
import com.zr.model.student;
import com.zr.util.ConnectionTool;

public class showAdmcouMsgDaoImpl implements showAdmcouMsgDao{

	@Override
	public int getConunt() {
		int count = 0;
		String sql = "select count(cid) ccount from course ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("ccount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<course> getPersoncourse(int page, int size) {
		List<course>  msgs =  new ArrayList<course>();
		String sql = "select * from course  limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				course  msg = new course();
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setCtime(rs.getString("ctime"));
				msg.setCtype(rs.getString("ctype"));
				msg.setCteacher(rs.getString("cteacher"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String insertcourseData(String cid, String cname, String ctime, String ctype, String cteacher) {
		System.out.println(cid);
		String  flag = "0";
		Connection connection = ConnectionTool.getconnection();
		String sql = "INSERT INTO course (cid, cname, ctime, ctype, cteacher) VALUES (?,?,?,?,?)";
		try {
		PreparedStatement pst = connection.prepareStatement(sql);
		pst.setString(1, cid);
		pst.setString(2, cname);
		pst.setString(3, ctime);
		pst.setString(4, ctype);
		pst.setString(5, cteacher);
		int  rs = pst.executeUpdate();
		if(rs>=1) {
			flag ="1";
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public String updatecourseDate(String cid, String cname, String ctime, String ctype, String cteacher) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update course set cname=?,ctime=?,ctype=?,cteacher=? where course.cid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, cname);
			pst.setString(2, ctime);
			pst.setString(3, ctype);
			pst.setString(4, cteacher);
			pst.setString(5, cid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String deletecourseDate(String cid) {
		String  u ="0";
		String sql = "delete from course where cid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst; 
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, cid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				u ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public course validateCidDao(String cid) {
		course  u =  new course();
		String sql = "select cid from course where cid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1,cid);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				u.setCid(rs.getInt("cid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  u;
	}

	@Override
	public List<course> searchAdmcouData(String cid, String ctime, String cteacher) throws SQLException {
		// TODO Auto-generated method stub
		List<course> courses = new ArrayList<course>();
		Connection connection = ConnectionTool.getconnection();
		StringBuilder sql=new StringBuilder("select * from course where ");
		String cid1 = "";
		String ctime1 = "";
		String cteacher1 = "";
		String and = "and ";
		if(cid.equals("")){
			cid1="cid!=''";
			System.out.println(1);
		}else{
			cid1="cid="+"\'"+cid+"\' ";
		}
		if(ctime.equals("")){
			ctime1="ctime!=''";
			System.out.println(2);
		}else{
			ctime1="ctime="+"\'"+ctime+"\' ";
		}
		if(cteacher.equals("")){
			cteacher1="cteacher!=''";
			System.out.println(3);
		}else{
			cteacher1="cteacher="+"\'"+cteacher+"\' ";
		}
		sql.append(cid1).append(and).append(ctime1).append(and).append(cteacher1);
		String sql1 = new String(sql);
		System.out.println(sql1);
		PreparedStatement pst = connection.prepareStatement(sql1);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			course course = new course();
			course.setCid(rs.getInt("cid"));
			course.setCname(rs.getString("cname"));
			course.setCtime(rs.getString("ctime"));
			course.setCtype(rs.getString("ctype"));
			course.setCteacher(rs.getString("cteacher"));
			courses.add(course);
			System.out.println(course);
		}
		System.out.println(rs);
		System.out.println(courses);
		return courses;
	}

}
