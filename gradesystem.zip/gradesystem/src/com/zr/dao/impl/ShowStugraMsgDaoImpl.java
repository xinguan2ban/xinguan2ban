package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.zr.dao.ShowStugraMsgDao;
import com.zr.model.grade;
import com.zr.util.ConnectionTool;

public class ShowStugraMsgDaoImpl implements ShowStugraMsgDao{

	@Override
	public int getConunt(String account) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(gid) ccount from grade where ");
		String sqlsid = "sid="+"\'"+account+"\' ";
		sql.append(sqlsid);
		String sql1 = new String(sql);
		//Connection 接口
		Connection connection = ConnectionTool.getconnection();
		//创建预处理对象PrepareStatement
		//PreparedStatement接口继承Statement,用于执行动态的SQL语句 ,通过PreparedStatement实例执行的SQL语句,
		//将被编译并保存到PreparedStatement实例中,从而可以重复的执行该SQL语句 . 
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			//executeQuery(String sql) 执行给定的Sql语句  返回单个ResultSet对象
			//ResultSet接口类似于一个临时的数据表,用来暂时存放数据库查询操作获取到的数据集  
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("ccount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<grade> getPersonGrade(int page, int size,String account) {
		List<grade>  msgs =  new ArrayList<grade>();
		String sqlsid = "sid="+"\'"+account+"\' ";
		String sql = "select * from grade where"+" "+sqlsid+ "limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				grade  msg = new grade();
				msg.setGid(rs.getInt("gid"));
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setCteacher(rs.getString("cteacher"));
				msg.setScore(rs.getString("score"));				
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  msgs;
	}

}
