package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.zr.dao.showAdmstuMsgDao;
import com.zr.model.student;
import com.zr.util.ConnectionTool;

public class showAdmstuMsgDaoImpl implements showAdmstuMsgDao{

	@Override
	public int getConunt() {
		int count = 0;
		String sql = "select count(sid) scount from student ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("scount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<student> getPersoncourse(int page, int size) {
		List<student>  msgs =  new ArrayList<student>();
		String sql = "select * from student  limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				student  msg = new student();
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setSsex(rs.getString("ssex"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setSpassword(rs.getString("spassword"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String insertstudentData(String sid, String sname,String ssex,String sclass,String smajor,String spassword) {
		System.out.println(sid);
		String  flag = "0";
		Connection connection = ConnectionTool.getconnection();
		String sql = "INSERT INTO student (sid,sname,ssex,sclass,smajor,spassword) VALUES (?,?,?,?,?,?)";
		try {
		PreparedStatement pst = connection.prepareStatement(sql);
		pst.setString(1, sid);
		pst.setString(2, sname);
		pst.setString(3, ssex);
		pst.setString(4, sclass);
		pst.setString(5, smajor);
		pst.setString(6, spassword);
		int  rs = pst.executeUpdate();
		if(rs>=1) {
			flag ="1";
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public String  updatestudentDate(String sid, String sname,String ssex,String sclass,String smajor,String spassword) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update student set sname=?,ssex=?,sclass=?,smajor=?,spassword=? where student.sid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, sname);
			pst.setString(2, ssex);
			pst.setString(3, sclass);
			pst.setString(4, smajor);
			pst.setString(5, spassword);
			pst.setString(6, sid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}


	@Override
	public String deletestudentDate(String sid) {
		String  u ="0";
		String sql = "delete from student where sid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst; 
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, sid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				u ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public student validateSidDao(String sid) {
		student  u =  new student();
		String sql = "select sid from student where sid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1,sid);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				u.setSid(rs.getInt("sid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  u;
	}

	@Override
	public List<student> searchAdmstuData(String sid, String sclass, String smajor) throws SQLException {
		// TODO Auto-generated method stub
		List<student> students = new ArrayList<student>();
		Connection connection = ConnectionTool.getconnection();
		StringBuilder sql=new StringBuilder("select * from student where ");
		String sid1 = "";
		String sclass1 = "";
		String smajor1 = "";
		String and = "and ";
		if(sid.equals("")){
			sid1="sid!=''";
			System.out.println(1);
		}else{
			sid1="sid="+"\'"+sid+"\' ";
		}
		if(sclass.equals("")){
			sclass1="sclass!=''";
			System.out.println(2);
		}else{
			sclass1="sclass="+"\'"+sclass+"\' ";
		}
		if(smajor.equals("")){
			smajor1="smajor!=''";
			System.out.println(3);
		}else{
			smajor1="smajor="+"\'"+smajor+"\' ";
		}
		sql.append(sid1).append(and).append(sclass1).append(and).append(smajor1);
		String sql1 = new String(sql);
		System.out.println(sql1);
		PreparedStatement pst = connection.prepareStatement(sql1);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			student student = new student();
			student.setSid(rs.getInt("sid"));
			student.setSname(rs.getString("sname"));
			student.setSsex(rs.getString("ssex"));
			student.setSclass(rs.getString("sclass"));
			student.setSmajor(rs.getString("smajor"));
			student.setSpassword(rs.getString("spassword"));
			students.add(student);
			System.out.println(student);
		}
		System.out.println(rs);
		System.out.println(students);
		return students;
	}

}
