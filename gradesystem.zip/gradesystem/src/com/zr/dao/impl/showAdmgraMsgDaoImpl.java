package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.dao.showAdmgraMsgDao;
import com.zr.model.course;
import com.zr.model.grade;
import com.zr.util.ConnectionTool;

public class showAdmgraMsgDaoImpl implements showAdmgraMsgDao{

	@Override
	public int getConunt() {
		int count = 0;
		String sql = "select count(gid) gcount from grade ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("gcount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<grade> getPersoncourse(int page, int size) {
		List<grade>  msgs =  new ArrayList<grade>();
		String sql = "select * from grade  limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				grade  msg = new grade();
				msg.setGid(rs.getInt("Gid"));
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setCteacher(rs.getString("cteacher"));
				msg.setScore(rs.getString("score"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String insertgradeData(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher,String score) {
		String  flag = "0";
		Connection connection = ConnectionTool.getconnection();
		String sql = "INSERT INTO grade (gid, sid, sname, cid, cname, sclass, smajor, cteacher, score) VALUES (?,?,?,?,?,?,?,?,?)";
		try {
		PreparedStatement pst = connection.prepareStatement(sql);
		pst.setString(1, gid);
		pst.setString(2, sid);
		pst.setString(3, sname);
		pst.setString(4, cid);
		pst.setString(5, cname);
		pst.setString(6, sclass);
		pst.setString(7, smajor);
		pst.setString(8, cteacher);
		pst.setString(9, score);
		int  rs = pst.executeUpdate();
		if(rs>=1) {
			flag ="1";
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public String updategradeDate(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher,String score) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update grade set sid=?,sname=?,cid=?,cname=?,sclass=?,smajor=?,cteacher=?,score=? where grade.gid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, sid);
			pst.setString(2, sname);
			pst.setString(3, cid);
			pst.setString(4, cname);
			pst.setString(5, sclass);
			pst.setString(6, smajor);
			pst.setString(7, cteacher);
			pst.setString(8, score);
			pst.setString(9, gid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public String deletegradeDate(String gid) {
		String  u ="0";
		String sql = "delete from grade where gid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst; 
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, gid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				u ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public grade validateGidDao(String gid) {
		grade  u =  new grade();
		String sql = "select gid from grade where gid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1,gid);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				u.setGid(rs.getInt("gid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  u;
	}

	@Override
	public List<grade> searchAdmgraData(String sname, String cname, String smajor) throws SQLException {
		// TODO Auto-generated method stub
		List<grade> grades = new ArrayList<grade>();
		Connection connection = ConnectionTool.getconnection();
		StringBuilder sql=new StringBuilder("select * from grade where ");
		String sname1 = "";
		String cname1 = "";
		String smajor1 = "";
		String and = "and ";
		if(sname.equals("")){
			sname1="sname!=''";
			System.out.println(1);
		}else{
			sname1="sname="+"\'"+sname+"\' ";
		}
		if(cname.equals("")){
			cname1="cname!=''";
			System.out.println(2);
		}else{
			cname1="cname="+"\'"+cname+"\' ";
		}
		if(smajor.equals("")){
			smajor1="smajor!=''";
			System.out.println(3);
		}else{
			smajor1="smajor="+"\'"+smajor+"\' ";
		}
		sql.append(sname1).append(and).append(cname1).append(and).append(smajor1);
		String sql1 = new String(sql);
		System.out.println(sql1);
		PreparedStatement pst = connection.prepareStatement(sql1);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			grade grade = new grade();
			grade.setGid(rs.getInt("gid"));
			grade.setSid(rs.getInt("sid"));
			grade.setSname(rs.getString("sname"));
			grade.setCid(rs.getInt("cid"));
			grade.setCname(rs.getString("cname"));
			grade.setSclass(rs.getString("sclass"));
			grade.setSmajor(rs.getString("smajor"));
			grade.setCteacher(rs.getString("cteacher"));
			grade.setScore(rs.getString("score"));
			grades.add(grade);
			System.out.println(grade);
		}
		System.out.println(rs);
		System.out.println(grades);
		return grades;
	}

}
