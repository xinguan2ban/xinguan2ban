package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.dao.showTeaDao;
import com.zr.model.grade;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.util.ConnectionTool;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class showTeaDaoImpl implements showTeaDao{

	@Override
	public JSONArray getFuncsByParentId(int parentId) {
		JSONArray jsonArray=new JSONArray();
		String sql="select * from functiontea where parentId=? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, parentId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				JSONObject jsonObject=new JSONObject();
				jsonObject.put("id", rs.getInt("fid"));
				jsonObject.put("text", rs.getString("fname"));
				jsonObject.put("state", rs.getString("fstate"));
				JSONObject  attr =  new JSONObject();
				//System.out.println(jsonObject);
				attr.put("furl", rs.getString("furl"));
				jsonObject.put("attributes", attr);
				jsonArray.add(jsonObject);
				//System.out.println(jsonArray);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return jsonArray;
	}

	@Override
	public JSONArray getAllByParentId(int parentId) {
		JSONArray jsonArray=this.getFuncsByParentId(parentId);
		for(int i=0;i<jsonArray.size();i++){
			JSONObject jsonObject=jsonArray.getJSONObject(i);
			if("open".equals(jsonObject.getString("state"))){
				continue;
			}else{
										//     1     2                  
	jsonObject.put("children", getAllByParentId(jsonObject.getInt("id")));
			}
		}
		return jsonArray;
	}

	@Override
	public String updateteacherDate(String tid, String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update teacher set tname=?,tsex=?,tpassword=?,ttocourse=?,ttodepartment=? where teacher.tid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, tname);
			pst.setString(2, tsex);
			pst.setString(3, tpassword);
			pst.setString(4, ttocourse);
			pst.setString(5, ttodepartment);
			pst.setString(6, tid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public List<teacher> getTeacherMsg(int page, int size,String account) {
		List<teacher>  msgs =  new ArrayList<teacher>();
		String sqltid = "tid="+"\'"+account+"\' ";
		String sql = "select * from teacher where "+" "+sqltid+ "limit  ?,? ";
		
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			System.out.println(sql);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				teacher  msg = new teacher();
				msg.setTid(rs.getInt("tid"));
				msg.setTname(rs.getString("tname"));
				msg.setTsex(rs.getString("tsex"));
				msg.setTpassword(rs.getString("tpassword"));
				msg.setTtocourse(rs.getString("ttocourse"));
				msg.setTtodepartment(rs.getString("ttodepartment"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("msgs"+msgs);
		return  msgs;
	}

	@Override
	public List<grade> getGradeMsg(int page,int size,String ttodepartment,String name) {
		System.out.println(ttodepartment+"miaomiao");
		List<grade>  msgs =  new ArrayList<grade>();
		String sqlsmajor = "smajor="+"\'"+ttodepartment+"\' ";
		String sqlcteacher = "cteacher="+"\'"+name+"\' ";
		String sql = "select * from grade where sclass='16级1班' and"+" "+sqlsmajor+ "and" + " " + sqlcteacher+"limit ?,?";

		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			System.out.println(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				grade  msg = new grade();
				msg.setGid(rs.getInt("Gid"));
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setCteacher(rs.getString("cteacher"));
				msg.setScore(rs.getString("score"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String updategradeDate(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher, String score) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update grade set sid=?,sname=?,cid=?,cname=?,sclass=?,smajor=?,cteacher=?,score=? where grade.gid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, sid);
			pst.setString(2, sname);
			pst.setString(3, cid);
			pst.setString(4, cname);
			pst.setString(5, sclass);
			pst.setString(6, smajor);
			pst.setString(7, cteacher);
			pst.setString(8, score);
			pst.setString(9, gid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public List<grade> getGrade1Msg(int page,int size,String ttodepartment,String name) {
		System.out.println(ttodepartment+"miaomiao");
		List<grade>  msgs =  new ArrayList<grade>();
		String sqlsmajor = "smajor="+"\'"+ttodepartment+"\' ";
		String sqlcteacher = "cteacher="+"\'"+name+"\' ";
		String sql = "select * from grade where sclass='16级2班' and"+" "+sqlsmajor+"and"+ " " + sqlcteacher+"limit ?,?";
		System.out.println();
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			System.out.println(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				grade  msg = new grade();
				msg.setGid(rs.getInt("Gid"));
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setCteacher(rs.getString("cteacher"));
				msg.setScore(rs.getString("score"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String updategrade1Date(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher, String score) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update grade set sid=?,sname=?,cid=?,cname=?,sclass=?,smajor=?,cteacher=?,score=? where grade.gid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, sid);
			pst.setString(2, sname);
			pst.setString(3, cid);
			pst.setString(4, cname);
			pst.setString(5, sclass);
			pst.setString(6, smajor);
			pst.setString(7, cteacher);
			pst.setString(8, score);
			pst.setString(9, gid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int getgraaConunt(String ttodepartment,String name) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(gid) gcount from grade where sclass='16级1班' and ");
		String sqlcteacher = " and cteacher="+"\'"+name+"\' ";
		String sqlsmajor = " smajor="+"\'"+ttodepartment+"\' ";
		sql.append(sqlsmajor);
		sql.append(sqlcteacher);
		String sql1 = new String(sql);
		System.out.println(sql1);

		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("gcount");
			}
			System.out.println(count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
		
	}
	
	@Override
	public int getgraConunt(String ttodepartment,String name) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(gid) gcount from grade where sclass='16级1班' and ");
		String sqlsmajor = "smajor="+"\'"+ttodepartment+"\' ";
		String sqlcteacher = "and cteacher="+"\'"+name+"\' ";
		sql.append(sqlsmajor);
		sql.append(sqlcteacher);
		String sql1 = new String(sql);
		System.out.println(sql1);

		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("gcount");
			}
			System.out.println(count);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
		
	}
	//获取id为多少得老师信息条数
	@Override
	public int getTeaConunt(String account) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(tid) tcount from teacher where ");
		String sqltid = "tid="+"\'"+account+"\' ";
		sql.append(sqltid);
		String sql1 = new String(sql);
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("tcount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}


}
