package com.zr.dao.impl;

import java.sql.Connection;
import com.zr.dao.LoginDao;
import com.zr.model.admin;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.util.ConnectionTool;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDaoImpl implements LoginDao {
	
	//通过账户将姓名查找出来
	@Override
	public String validateName(String redioname ,String account) {
		Connection connection = ConnectionTool.getconnection();
		String adminsql = "select aname from admin where aid=?";
		String teachersql = "select tname from teacher where tid=?";
		String studentsql = "select sname from student where sid=?";
		String aname = null;
		String tname = null;
		String sname = null;
		if (redioname.equals("管理员")) {
		try {
			PreparedStatement pst = connection.prepareStatement(adminsql);
			pst.setString(1, account);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				aname = rs.getString("aname");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return aname;
		}else if (redioname.equals("教师")) {
			try {
				PreparedStatement pst = connection.prepareStatement(teachersql);
				pst.setString(1, account);
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					tname = rs.getString("tname");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return tname;			
		}else {
			try {
				PreparedStatement pst = connection.prepareStatement(studentsql);
				pst.setString(1, account);
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					sname = rs.getString("sname");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return sname;	
		}
	}
	


	@Override
	public boolean validatePassword(String redioname, String account, String password) {
		String apassword = null;
		String tpassword = null;
		String spassword = null;
		Connection connection = ConnectionTool.getconnection();
		String sqladmin = "select apassword from admin where aid=?";
		String sqlteacher = "select tpassword from teacher where tid=?";
		String sqlstudent = "select spassword from student where sid=?";
		PreparedStatement pst1;
		//当redioname为管理员时通过sql语句将admin的密码查询出来
		if (redioname.equals("管理员")) {			
			try {
				PreparedStatement pst11 = connection.prepareStatement(sqladmin);
				pst11.setString(1, account);
				ResultSet  rs = pst11.executeQuery();
				while (rs.next()) {
					apassword = rs.getString("apassword");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (password.equals(apassword)) {
				return true;
			}else{
				return false;
			}
			
		}else if (redioname.equals("教师")) {
			try {
				PreparedStatement pst21 = connection.prepareStatement(sqlteacher);
				pst21.setString(1, account);
				ResultSet  rs = pst21.executeQuery();
				while (rs.next()) {
					tpassword = rs.getString("tpassword");
					System.out.println("123456"+tpassword);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (password.equals(tpassword)) {
				System.out.println("password"+password);
				System.out.println("tpassword"+tpassword);
				return true;
			}else{
				return false;
			}
		}else{
			try {
				PreparedStatement pst = connection.prepareStatement(sqlstudent);
				pst.setString(1, account);
				ResultSet  rs = pst.executeQuery();
				while (rs.next()) {
					spassword = rs.getString("spassword");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (password.equals(spassword)) {
				return true;
			}else{
				return false;
			}
		}
	
	}



	@Override
	public boolean validateAccount(String redioname ,String account) {
		admin admin = new admin();
		teacher teacher = new teacher();
		student student = new student();
		Connection connection = ConnectionTool.getconnection();
		String sqladmin = "select aid,aname from admin where aid=?";
		String sqlteacher = "select tid,tname from teacher where tid=?";
		String sqlstudent = "select sid,sname from student where sid=?";
		PreparedStatement pst;
		if (redioname.equals("管理员")) {
			try {
				pst = connection.prepareStatement(sqladmin);
				pst.setString(1, account);
				ResultSet  rs = pst.executeQuery();
				if(rs.next()){
					admin.setAid(rs.getInt("aid"));
					admin.setAname(rs.getString("aname"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			    if(admin.getAid()>=1){
			    	return true;
			    }else {
					return false;
				}
		}else if (redioname.equals("教师")) {
			try {
				pst = connection.prepareStatement(sqlteacher);
				pst.setString(1, account);
				ResultSet  rs = pst.executeQuery();
				if(rs.next()){
					teacher.setTid(rs.getInt("tid"));
					teacher.setTname(rs.getString("tname"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			    if(teacher.getTid()>=1){
			    	return true;
			    }else {
					return false;
				}
		}else {
			try {
				pst = connection.prepareStatement(sqlstudent);
				pst.setString(1, account);
				ResultSet  rs = pst.executeQuery();
				if(rs.next()){
					student.setSid(rs.getInt("sid"));
					student.setSname(rs.getString("sname"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			    if(student.getSid()>=1){
			    	return true;
			    }else {
					return false;
				}
		}

	}



	@Override
	public String validatettodepartment(String account) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "select ttodepartment from teacher where tid=?";
		String ttodepartment = null;
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, account);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				ttodepartment = rs.getString("ttodepartment");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return ttodepartment;			
			
		}
	}
	
	




