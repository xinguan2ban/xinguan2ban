package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.dao.ShowStuDao;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.service.ShowStuService;
import com.zr.util.ConnectionTool;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ShowStuDaoImpl implements ShowStuDao{
	/**
	 * 根据父亲id获取当前父节点的功能列表
	 * @param parentId
	 * @return
	 */
	@Override
	public JSONArray getFuncsByParentId(int parentId) {
		JSONArray jsonArray=new JSONArray();
		String sql="select * from functionstu where parentId=? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, parentId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				JSONObject jsonObject=new JSONObject();
				jsonObject.put("id", rs.getInt("fid"));
				jsonObject.put("text", rs.getString("fname"));
				jsonObject.put("state", rs.getString("fstate"));
				JSONObject  attr =  new JSONObject();
				//System.out.println(jsonObject);
				attr.put("furl", rs.getString("furl"));
				jsonObject.put("attributes", attr);
				jsonArray.add(jsonObject);
				//System.out.println(jsonArray);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return jsonArray;
	}
	
	/**
	 * 真的是在组装数据
	 * @param parentId
	 * @return
	 * @throws Exception
	 */
	//
	@Override
	public JSONArray getAllByParentId(int parentId) {
		JSONArray jsonArray=this.getFuncsByParentId(parentId);
		for(int i=0;i<jsonArray.size();i++){
			JSONObject jsonObject=jsonArray.getJSONObject(i);
			if("open".equals(jsonObject.getString("state"))){
				continue;
			}else{
										//     1     2                  
	jsonObject.put("children", getAllByParentId(jsonObject.getInt("id")));
			}
		}
		return jsonArray;
	}

	@Override
	public List<student> getstudentMsg(int page, int size,String account) {
		List<student>  msgs =  new ArrayList<student>();
		String sqlsid = "sid="+"\'"+account+"\' ";
		String sql = "select * from student where"+" "+sqlsid+ "limit  ?,? ";
		
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			System.out.println(sql);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				student  msg = new student();
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setSsex(rs.getString("ssex"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setSpassword(rs.getString("spassword"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String  updatestudentDate(String sid, String sname,String ssex,String sclass,String smajor,String spassword){
		Connection connection = ConnectionTool.getconnection();
		String sql = "update student set sname=?,ssex=?,sclass=?,smajor=?,spassword=? where student.sid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, sname);
			pst.setString(2, ssex);
			pst.setString(3, sclass);
			pst.setString(4, smajor);
			pst.setString(5, spassword);
			pst.setString(6, sid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int getConunt(String account) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(sid) scount from student where ");
		String sqlsid = "sid="+"\'"+account+"\' ";
		sql.append(sqlsid);
		String sql1 = new String(sql);
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("scount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	

}
