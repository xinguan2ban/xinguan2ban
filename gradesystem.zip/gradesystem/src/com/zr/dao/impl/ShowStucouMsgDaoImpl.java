package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.zr.dao.ShowStucouMsgDao;
import com.zr.model.yixuancourse;
import com.zr.util.ConnectionTool;

public class ShowStucouMsgDaoImpl implements ShowStucouMsgDao{

	@Override
	public int getConunt(String account) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(yid) ycount from yixuancourse where ");
		String sqlsid = "sid="+"\'"+account+"\' ";
		sql.append(sqlsid);
		String sql1 = new String(sql);
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("ycount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<yixuancourse> getPersoncourse(int page, int size,String account) {
		List<yixuancourse>  msgs =  new ArrayList<yixuancourse>();
		String sqlsid = "sid="+"\'"+account+"\' ";
		String sql = "select * from yixuancourse where"+" "+sqlsid+ "limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				yixuancourse  msg = new yixuancourse();
				msg.setYid(rs.getInt("yid"));
				msg.setCid(rs.getInt("cid"));
				msg.setCname(rs.getString("cname"));
				msg.setSid(rs.getInt("sid"));
				msg.setSname(rs.getString("sname"));
				msg.setSclass(rs.getString("sclass"));
				msg.setSmajor(rs.getString("smajor"));
				msg.setCtype(rs.getString("ctype"));
				msg.setCteacher(rs.getString("cteacher"));
				msg.setYstate(rs.getString("ystate"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

}
