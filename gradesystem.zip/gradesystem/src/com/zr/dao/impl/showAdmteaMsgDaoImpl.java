package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.zr.dao.showAdmteaMsgDao;
import com.zr.model.teacher;
import com.zr.util.ConnectionTool;

public class showAdmteaMsgDaoImpl implements showAdmteaMsgDao{

	@Override
	public int getConunt() {
		int count = 0;
		String sql = "select count(tid) tcount from teacher ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("tcount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

	@Override
	public List<teacher> getPersoncourse(int page, int size) {
		List<teacher>  msgs =  new ArrayList<teacher>();
		String sql = "select * from teacher  limit  ?,? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setInt(1, (page-1)*size);
			pst.setInt(2, size);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				teacher  msg = new teacher();
				msg.setTid(rs.getInt("tid"));
				msg.setTname(rs.getString("tname"));
				msg.setTsex(rs.getString("tsex"));
				msg.setTpassword(rs.getString("tpassword"));
				msg.setTtocourse(rs.getString("ttocourse"));
				msg.setTtodepartment(rs.getString("ttodepartment"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String insertteacherData(String tid, String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		System.out.println(tid);
		String  flag = "0";
		Connection connection = ConnectionTool.getconnection();
		String sql = "INSERT INTO teacher (tid,tname,tsex,tpassword,ttocourse,ttodepartment) VALUES (?,?,?,?,?,?)";
		try {
		PreparedStatement pst = connection.prepareStatement(sql);
		pst.setString(1, tid);
		pst.setString(2, tname);
		pst.setString(3, tsex);
		pst.setString(4, tpassword);
		pst.setString(5, ttocourse);
		pst.setString(6, ttodepartment);
		int  rs = pst.executeUpdate();
		if(rs>=1) {
			flag ="1";
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	@Override
	public String  updateteacherDate(String tid,String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update teacher set tname=?,tsex=?,tpassword=?,ttocourse=?,ttodepartment=? where teacher.tid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, tname);
			pst.setString(2, tsex);
			pst.setString(3, tpassword);
			pst.setString(4, ttocourse);
			pst.setString(5, ttodepartment);
			pst.setString(6, tid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}


	@Override
	public String deleteteacherDate(String tid) {
		String  u ="0";
		String sql = "delete from teacher where tid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst; 
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, tid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				u ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return u;
	}

	@Override
	public teacher validateTidDao(String tid) {
		teacher  u =  new teacher();
		String sql = "select tid from teacher where tid=?";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1,tid);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				u.setTid(rs.getInt("tid"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return  u;
	}

	@Override
	public List<teacher> searchAdmteaData(String tid, String ttocourse, String ttodepartment) throws SQLException {
		// TODO Auto-generated method stub
		List<teacher> teachers = new ArrayList<teacher>();
		Connection connection = ConnectionTool.getconnection();
		StringBuilder sql=new StringBuilder("select * from teacher where ");
		String tid1 = "";
		String ttocourse1 = "";
		String ttodepartment1 = "";
		String and = "and ";
		if(tid.equals("")){
			tid1="tid!=''";
			System.out.println(1);
		}else{
			tid1="tid="+"\'"+tid+"\' ";
		}
		if(ttocourse.equals("")){
			ttocourse1="ttocourse!=''";
			System.out.println(2);
		}else{
			ttocourse1="ttocourse="+"\'"+ttocourse+"\' ";
		}
		if(ttodepartment.equals("")){
			ttodepartment1="ttodepartment!=''";
			System.out.println(3);
		}else{
			ttodepartment1="ttodepartment="+"\'"+ttodepartment+"\' ";
		}
		sql.append(tid1).append(and).append(ttocourse1).append(and).append(ttodepartment1);
		String sql1 = new String(sql);
		System.out.println(sql1);
		PreparedStatement pst = connection.prepareStatement(sql1);
		ResultSet rs = pst.executeQuery();
		while (rs.next()) {
			teacher teacher = new teacher();
			teacher.setTid(rs.getInt("tid"));
			teacher.setTname(rs.getString("tname"));
			teacher.setTpassword(rs.getString("tpassword"));
			teacher.setTsex(rs.getString("tsex"));
			teacher.setTtocourse(rs.getString("ttocourse"));
			teacher.setTtodepartment(rs.getString("ttodepartment"));
			teachers.add(teacher);
			System.out.println(teacher);
		}
		System.out.println(rs);
		System.out.println(teachers);
		return teachers;
	}

}
