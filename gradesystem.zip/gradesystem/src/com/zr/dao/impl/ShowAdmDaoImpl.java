package com.zr.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.zr.dao.ShowAdmDao;
import com.zr.model.admin;
import com.zr.model.student;
import com.zr.util.ConnectionTool;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ShowAdmDaoImpl implements ShowAdmDao{
	/**
	 * 根据父亲id获取当前父节点的功能列表
	 * @param parentId
	 * @return
	 */
	@Override
	public JSONArray getFuncsByParentId(int parentId) {
		JSONArray jsonArray=new JSONArray();
		String sql="select * from functionadm where parentId=? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, parentId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				JSONObject jsonObject=new JSONObject();
				jsonObject.put("id", rs.getInt("fid"));
				jsonObject.put("text", rs.getString("fname"));
				jsonObject.put("state", rs.getString("fstate"));
				JSONObject  attr =  new JSONObject();
				//System.out.println(jsonObject);
				attr.put("furl", rs.getString("furl"));
				jsonObject.put("attributes", attr);
				jsonArray.add(jsonObject);
				//System.out.println(jsonArray);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return jsonArray;
	}
	
	/**
	 * 真的是在组装数据
	 * @param parentId
	 * @return
	 * @throws Exception
	 */
	@Override
	public JSONArray getAllByParentId(int parentId) {
		JSONArray jsonArray=this.getFuncsByParentId(parentId);
		for(int i=0;i<jsonArray.size();i++){
			JSONObject jsonObject=jsonArray.getJSONObject(i);
			if("open".equals(jsonObject.getString("state"))){
				continue;
			}else{
										//     1     2                  
	jsonObject.put("children", getAllByParentId(jsonObject.getInt("id")));
			}
		}
		return jsonArray;
	}

	@Override
	public List<admin> getadminMsg(String account) {
		List<admin>  msgs =  new ArrayList<admin>();
		String sql = "select * from admin where aid=? ";
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql);
			pst.setString(1, account);
			ResultSet  rs = pst.executeQuery();
			while(rs.next()){
				admin  msg = new admin();
				msg.setAid(rs.getInt("aid"));
				msg.setAname(rs.getString("aname"));
				msg.setApassword(rs.getString("apassword"));
				msg.setAsex(rs.getString("asex"));
				msgs.add(msg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return  msgs;
	}

	@Override
	public String updateadminDate(String aid, String aname, String apassword, String asex) {
		Connection connection = ConnectionTool.getconnection();
		String sql = "update admin set apassword=?,aname=?,asex=? where admin.aid=?";
		String flag = "0";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, apassword);
			pst.setString(2, aname);
			pst.setString(3, asex);
			pst.setString(4, aid);
			int  rs = pst.executeUpdate();
			if(rs>=1) {
				flag ="1";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public int getConunt(String account) {
		int count = 0;
		StringBuffer sql = new StringBuffer("select count(aid) acount from admin where ");
		String sqlaid = "aid="+"\'"+account+"\' ";
		sql.append(sqlaid);
		String sql1 = new String(sql);
		Connection connection = ConnectionTool.getconnection();
		PreparedStatement pst;
		try {
			pst = connection.prepareStatement(sql1);
			ResultSet  rs = pst.executeQuery();
			if(rs.next()){
				count = rs.getInt("acount");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  count;
	}

}
