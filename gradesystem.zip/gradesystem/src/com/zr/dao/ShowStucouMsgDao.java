package com.zr.dao;

import java.util.List;


import com.zr.model.yixuancourse;

public interface ShowStucouMsgDao {
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getConunt(String account);
	
	public List<yixuancourse> getPersoncourse(int page,int size,String account);
}
