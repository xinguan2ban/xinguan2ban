package com.zr.dao;

import java.sql.SQLException;
import java.util.List;

import com.zr.model.student;
import com.zr.model.teacher;


public interface showAdmstuMsgDao {
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getConunt();
	
	public List<student> getPersoncourse(int page,int size);
	/**
	 * 添加教师信息
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public String insertstudentData(String sid, String sname,String ssex,String sclass,String smajor,String spassword);
	
	public String  updatestudentDate(String sid, String sname,String ssex,String sclass,String smajor,String spassword);
	
	public String deletestudentDate(String sid);
	
	public student validateSidDao(String sid);
	
	public List<student> searchAdmstuData(String sid,String sclass,String smajor)throws SQLException;
}
