package com.zr.dao;

import java.util.List;

import com.zr.model.grade;
import com.zr.model.student;
import com.zr.model.teacher;

import net.sf.json.JSONArray;

public interface showTeaDao {
	/**
	 * 根据父亲id获取当前父节点的功能列表
	 * @param parentId
	 * @return
	 */
	public JSONArray getFuncsByParentId(int parentId);
	
	/**
	 * 真的是在组装数据
	 * @param parentId
	 * @return
	 * @throws Exception
	 */
	//	
	public JSONArray getAllByParentId(int parentId);
	
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getTeaConunt(String account);
	public int getgraaConunt(String ttodepartment,String name);
	
	public int getgraConunt(String ttodepartment,String name);
	
	public String  updateteacherDate(String tid, String tname,String tsex,
			String tpassword,String ttocourse,String ttodepartment);
	
	public List<teacher> getTeacherMsg(int page,int size,String account);
	
	public List<grade> getGradeMsg(int page,int size,String ttodepartment,String name);
	
	public String  updategradeDate(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor,String cteacher, String score);

	public List<grade> getGrade1Msg(int page,int size,String ttodepartment,String name);
	
	public String  updategrade1Date(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor,String cteacher, String score);

}
