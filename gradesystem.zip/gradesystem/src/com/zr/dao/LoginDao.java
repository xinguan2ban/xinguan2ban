package com.zr.dao;



public interface LoginDao {
	//验证密码方法
	public boolean validatePassword(String redioname ,String account,String password);
	//查找用户姓名方法
	public String validateName(String redioname ,String account);
	
	public String validatettodepartment(String account);
	//验证用户是否存在
	public boolean validateAccount(String redioname ,String account);
}
