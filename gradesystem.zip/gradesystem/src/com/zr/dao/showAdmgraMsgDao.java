package com.zr.dao;

import java.sql.SQLException;
import java.util.List;

import com.zr.model.course;
import com.zr.model.grade;

public interface showAdmgraMsgDao {
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getConunt();
	
	public List<grade> getPersoncourse(int page,int size);
	/**
	 * 添加教师信息
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public String insertgradeData(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor,String cteacher,String score);
	
	public String  updategradeDate(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor,String cteacher, String score);
	
	public String deletegradeDate(String gid);
	
	public grade validateGidDao(String gid);
	
	public List<grade> searchAdmgraData(String sname,String cname,String smajor)throws SQLException;
}
