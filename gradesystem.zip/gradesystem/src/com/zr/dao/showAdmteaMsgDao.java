package com.zr.dao;

import java.sql.SQLException;
import java.util.List;
import com.zr.model.teacher;


public interface showAdmteaMsgDao {
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getConunt();
	
	public List<teacher> getPersoncourse(int page,int size);
	/**
	 * 添加教师信息
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public String insertteacherData(String tid, String tname,String tsex,
			String tpassword,String ttocourse,String ttodepartment);
	
	public String  updateteacherDate(String tid, String tname,String tsex,
			String tpassword,String ttocourse,String ttodepartment);
	
	public String deleteteacherDate(String tid);
	
	public teacher validateTidDao(String tid);
	
	public List<teacher> searchAdmteaData(String tid,String ttocourse,String ttodepartment)throws SQLException;
}
