package com.zr.dao;

import java.util.List;

import com.zr.model.admin;
import com.zr.model.student;

import net.sf.json.JSONArray;

public interface ShowAdmDao {
	/**
	 * 根据父亲id获取当前父节点的功能列表
	 * @param parentId
	 * @return
	 */
	public JSONArray getFuncsByParentId(int parentId);
	
	/**
	 * 真的是在组装数据
	 * @param parentId
	 * @return
	 * @throws Exception
	 */
	//	
	public JSONArray getAllByParentId(int parentId);
	
	public int getConunt(String account);
	/**
	 * 获取学生个人信息
	 * @param account
	 * @return
	 */
	public List<admin> getadminMsg(String account);
	
	
	public String updateadminDate(String aid, String aname,String apassword,String asex);

}
