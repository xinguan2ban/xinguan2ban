package com.zr.dao;

import java.util.List;

import com.zr.model.student;
import com.zr.model.teacher;

import net.sf.json.JSONArray;

public interface ShowStuDao {
	/**
	 * 根据父亲id获取当前父节点的功能列表
	 * @param parentId
	 * @return
	 */
	public JSONArray getFuncsByParentId(int parentId);
	
	/**
	 * 真的是在组装数据
	 * @param parentId
	 * @return
	 * @throws Exception
	 */
	//	
	public JSONArray getAllByParentId(int parentId);
	
	public int getConunt(String account);
	/**
	 * 获取学生个人信息
	 * @param account
	 * @return
	 */
	public List<student> getstudentMsg(int page,int size,String account);
	
	
	public String  updatestudentDate(String sid, String sname,String ssex,String sclass,String smajor,String spassword);
}
