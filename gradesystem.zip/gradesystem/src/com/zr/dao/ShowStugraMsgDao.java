package com.zr.dao;

import java.util.List;


import com.zr.model.grade;

public interface ShowStugraMsgDao {
	public int getConunt(String account);
	public List<grade> getPersonGrade(int page,int size,String account);
}
