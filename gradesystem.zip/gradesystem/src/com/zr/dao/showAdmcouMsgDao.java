package com.zr.dao;

import java.sql.SQLException;
import java.util.List;

import com.zr.model.course;


public interface showAdmcouMsgDao {
	/**
	 * 获取数据的总数
	 * @return
	 */
	public int getConunt();
	
	public List<course> getPersoncourse(int page,int size);
	/**
	 * 添加教师信息
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public String insertcourseData(String cid, String cname,String ctime,String ctype,String cteacher);
	
	public String  updatecourseDate(String cid, String cname,String ctime,String ctype,String cteacher);
	
	public String deletecourseDate(String cid);
	
	public course validateCidDao(String cid);
	
	public List<course> searchAdmcouData(String cid,String ctime,String cteacher)throws SQLException;
}
