package com.zr.service;

import net.sf.json.JSONObject;

public interface showAdmcouMsgService {
	public JSONObject  showcmPersonMsg(int page,int size);
	//添
	public String insertcourse(String cid, String cname,String ctime,String ctype,String cteacher);
	public String updatecourse(String cid, String cname,String ctime,String ctype,String cteacher);
	public String deletecourse(String cid);
	public boolean validateCidService(String cid);
	public JSONObject searchAdmcouMsg(String cid,String ctime,String cteacher);
}
