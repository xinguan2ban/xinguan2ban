package com.zr.service;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public interface ShowAdmService {
	/**
	 * 返回datagrid要求的数据格式
	 * @param page
	 * @param size
	 * @return
	 */
	public  JSONArray  showFuncs(int parentId);
	
	
	/**
	 * 获取学生个人信息
	 * @param account
	 * @return
	 */
	public JSONObject  showcmPersonMsg(int page, int size,String account);
	
	public String updateadmin(String aid, String aname,String apassword,String asex);

}
