package com.zr.service;



import net.sf.json.JSONObject;

public interface showAdmstuMsgService {
	public JSONObject  showcmPersonMsg(int page,int size);
	//添
	public String insertstudent(String sid, String sname,String ssex,String sclass,String smajor,String spassword);
	public String updatestudent(String sid, String sname,String ssex,String sclass,String smajor,String spassword);
	public String deletestudent(String sid);
	public boolean validateSidService(String sid);
	public JSONObject searchAdmstuMsg(String sid,String sclass,String smajor);
	

}
