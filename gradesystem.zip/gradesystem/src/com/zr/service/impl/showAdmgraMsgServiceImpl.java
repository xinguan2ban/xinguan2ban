package com.zr.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.zr.dao.showAdmcouMsgDao;
import com.zr.dao.showAdmgraMsgDao;
import com.zr.dao.impl.showAdmcouMsgDaoImpl;
import com.zr.dao.impl.showAdmgraMsgDaoImpl;
import com.zr.model.course;
import com.zr.model.grade;
import com.zr.service.showAdmgraMsgService;

import net.sf.json.JSONObject;

public class showAdmgraMsgServiceImpl implements showAdmgraMsgService{
	showAdmgraMsgDao sat = new showAdmgraMsgDaoImpl();

	@Override
	public JSONObject showcmPersonMsg(int page, int size) {
		 int count =    sat.getConunt();
		 List<grade>  msgs = sat.getPersoncourse(page, size);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}

	@Override
	public String insertgrade(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor,String cteacher, String score) {
		String ser = sat.insertgradeData(gid, sid, sname, cid, cname, sclass, smajor,cteacher, score);
		return ser;
	}

	@Override
	public String updategrade(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher,String score) {
		String upd = sat.updategradeDate(gid, sid, sname, cid, cname, sclass, smajor, cteacher,score);
		return upd;
	}

	@Override
	public String deletegrade(String gid) {
		String del = sat.deletegradeDate(gid);
		return del;
	}

	@Override
	public boolean validateGidService(String gid) {
		boolean flag = false;
		 grade u=  sat.validateGidDao(gid);//返回一个数组  
		    if(u.getGid()>=1){
		    	flag = true;
		    }
		    return  flag;
	}

	@Override
	public JSONObject searchAdmgraMsg(String sname, String cname, String smajor) {
		 JSONObject  js = new JSONObject();
			
		try {
			int scount = 0;
			List<grade> grades = sat.searchAdmgraData(sname, cname, smajor);
			for (grade grade : grades) {
				scount++;
			}
			js.put("total",scount);
			js.put("rows", grades);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		 return js;
	}

}
