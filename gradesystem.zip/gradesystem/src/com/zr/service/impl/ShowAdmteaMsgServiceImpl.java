package com.zr.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.zr.dao.showAdmteaMsgDao;
import com.zr.dao.impl.showAdmteaMsgDaoImpl;
import com.zr.model.teacher;
import com.zr.service.showAdmteaMsgService;
import net.sf.json.JSONObject;

public class ShowAdmteaMsgServiceImpl implements showAdmteaMsgService{
	showAdmteaMsgDao sat = new showAdmteaMsgDaoImpl();
	@Override
		public JSONObject showcmPersonMsg(int page, int size) {
			 int count =    sat.getConunt();
			 List<teacher>  msgs = sat.getPersoncourse(page, size);
			 JSONObject  js = new JSONObject();
			 js.put("total", count);
			 js.put("rows", msgs);
			 return js;
	}
	@Override
	public String insertteacher(String tid, String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		String ser = sat.insertteacherData(tid, tname, tsex, tpassword, ttocourse, ttodepartment);
		return ser;
	}
	@Override
	public String updateteacher(String tid, String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		String upd = sat.updateteacherDate(tid, tname, tsex, tpassword, ttocourse, ttodepartment);
		return upd;
	}
	@Override
	public String deleteteacher(String tid) {
		String del = sat.deleteteacherDate(tid);
		return del;
	}
	@Override
	public boolean validateTidService(String tid) {
		 boolean flag = false;
		 teacher u=  sat.validateTidDao(tid);//返回一个数组  
		    if(u.getTid()>=1){
		    	flag = true;
		    }
		    return  flag;
	}
	@Override
	public JSONObject searchAdmteaMsg(String tid, String ttocourse, String ttodepartment) {
		 JSONObject  js = new JSONObject();
		
		try {
			int scount = 0;
			List<teacher> teachers = sat.searchAdmteaData(tid, ttocourse, ttodepartment);
			for (teacher teacher : teachers) {
				scount++;
			}
			js.put("total",scount);
			js.put("rows", teachers);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		 return js;
	}

}
