package com.zr.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.zr.dao.showAdmcouMsgDao;
import com.zr.dao.impl.showAdmcouMsgDaoImpl;
import com.zr.model.course;
import com.zr.model.student;
import com.zr.service.showAdmcouMsgService;

import net.sf.json.JSONObject;

public class showAdmcouMsgServiceImpl implements showAdmcouMsgService{
	showAdmcouMsgDao sat = new showAdmcouMsgDaoImpl();

	@Override
	public JSONObject showcmPersonMsg(int page, int size) {
		 int count =    sat.getConunt();
		 List<course>  msgs = sat.getPersoncourse(page, size);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}

	@Override
	public String insertcourse(String cid, String cname, String ctime, String ctype, String cteacher) {
		String ser = sat.insertcourseData(cid, cname, ctime, ctype, cteacher);
		return ser;
	}

	@Override
	public String updatecourse(String cid, String cname, String ctime, String ctype, String cteacher) {
		String upd = sat.updatecourseDate(cid, cname, ctime, ctype, cteacher);
		return upd;
	}

	@Override
	public String deletecourse(String cid) {
		String del = sat.deletecourseDate(cid);
		return del;
	}

	@Override
	public boolean validateCidService(String cid) {
		 boolean flag = false;
		 course u=  sat.validateCidDao(cid);//返回一个数组  
		    if(u.getCid()>=1){
		    	flag = true;
		    }
		    return  flag;
	}

	@Override
	public JSONObject searchAdmcouMsg(String cid, String ctime, String cteacher) {
		 JSONObject  js = new JSONObject();
			
		try {
			int scount = 0;
			List<course> courses = sat.searchAdmcouData(cid, ctime, cteacher);
			for (course course : courses) {
				scount++;
			}
			js.put("total",scount);
			js.put("rows", courses);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		 return js;
	}

}
