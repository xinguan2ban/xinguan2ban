package com.zr.service.impl;

import java.util.List;

import com.zr.dao.ShowStuDao;
import com.zr.dao.impl.ShowStuDaoImpl;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.service.ShowStuService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ShowStuServiceImpl implements ShowStuService{
	ShowStuDao ssd = new ShowStuDaoImpl();
	/**
	 * 返回datagrid要求的数据格式
	 * @param page
	 * @param size
	 * @return
	 */
	@Override
	public JSONArray showFuncs(int parentId) {
		
		return ssd.getAllByParentId(parentId);
	}
	@Override
	public JSONObject showcmPersonMsg(int page, int size,String account) {
		int count =    ssd.getConunt(account);
		 List<student>  msgs = ssd.getstudentMsg(page,size,account);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}
	@Override
	public String updatestudent(String sid, String sname,String ssex,String sclass,String smajor,String spassword) {
		String upd = ssd.updatestudentDate(sid, sname, ssex, sclass, smajor, spassword);
		return upd;
	}
	
}
