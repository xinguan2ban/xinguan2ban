package com.zr.service.impl;

import java.util.List;

import com.zr.dao.ShowAdmDao;
import com.zr.dao.impl.ShowAdmDaoImpl;
import com.zr.model.admin;
import com.zr.model.student;
import com.zr.service.ShowAdmService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ShowAdmServiceImpl implements ShowAdmService{
	ShowAdmDao sad = new ShowAdmDaoImpl();
	@Override
	public JSONArray showFuncs(int parentId) {
		// TODO Auto-generated method stub
		return sad.getAllByParentId(parentId);
	}
	@Override
	public JSONObject showcmPersonMsg(int page, int size,String account) {
		int count =    sad.getConunt(account);
		 List<admin>  msgs = sad.getadminMsg(account);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}
	@Override
	public String updateadmin(String aid, String aname, String apassword, String asex) {
		String upd = sad.updateadminDate(aid, aname, apassword, asex);
		return upd;
	}

}
