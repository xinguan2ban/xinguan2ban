package com.zr.service.impl;

import java.sql.SQLException;
import java.util.List;

import com.zr.dao.showAdmstuMsgDao;
import com.zr.dao.impl.showAdmstuMsgDaoImpl;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.service.showAdmstuMsgService;

import net.sf.json.JSONObject;

public class ShowAdmstuMsgServiceImpl implements showAdmstuMsgService{
	showAdmstuMsgDao sat = new showAdmstuMsgDaoImpl();
	@Override
		public JSONObject showcmPersonMsg(int page, int size) {
			 int count =    sat.getConunt();
			 List<student>  msgs = sat.getPersoncourse(page, size);
			 JSONObject  js = new JSONObject();
			 js.put("total", count);
			 js.put("rows", msgs);
			 return js;
	}
	@Override
	public String insertstudent(String sid, String sname, String ssex, String sclass, String smajor,
			String spassword) {
		String ser = sat.insertstudentData(sid, sname, ssex, sclass, smajor, spassword);
		return ser;
	}
	@Override
	public String updatestudent(String sid, String sname, String ssex, String sclass, String smajor,
			String spassword) {
		String upd = sat.updatestudentDate(sid, sname, ssex, sclass, smajor, spassword);
		return upd;
	}
	@Override
	public String deletestudent(String sid) {
		String del = sat.deletestudentDate(sid);
		return del;
	}
	@Override
	public boolean validateSidService(String sid) {
		 boolean flag = false;
		 student u=  sat.validateSidDao(sid);//返回一个数组  
		    if(u.getSid()>=1){
		    	flag = true;
		    }
		    return  flag;
	}
	@Override
	public JSONObject searchAdmstuMsg(String sid, String sclass, String smajor) {
		 JSONObject  js = new JSONObject();
		
		try {
			int scount = 0;
			List<student> students = sat.searchAdmstuData(sid, sclass, smajor);
			for (student student : students) {
				scount++;
			}
			js.put("total",scount);
			js.put("rows", students);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		 return js;
	}

}
