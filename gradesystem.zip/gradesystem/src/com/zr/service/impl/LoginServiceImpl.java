package com.zr.service.impl;



import com.zr.dao.LoginDao;
import com.zr.dao.impl.LoginDaoImpl;
import com.zr.service.LoginService;

public class LoginServiceImpl implements LoginService{
	LoginDao ld = new LoginDaoImpl();

	public String validateNa(String redioname ,String account) {
		String name = ld.validateName(redioname ,account);
		return name;
	}

	@Override
	public boolean validatePws(String redioname, String account, String password) {
		boolean flag = false;
		flag = ld.validatePassword(redioname, account, password);

		return flag;
	}
	@Override
	public boolean validateAccount(String redioname ,String account) {
		boolean flag1 = false;
		flag1 = ld.validateAccount(redioname, account);
	    return  flag1;
	}

	@Override
	public String validatettodepartment(String account) {
		String ttodepartment = ld.validatettodepartment(account);
		return ttodepartment;
	}
	

}
