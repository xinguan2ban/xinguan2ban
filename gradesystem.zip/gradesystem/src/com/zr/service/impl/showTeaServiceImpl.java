package com.zr.service.impl;

import java.util.List;

import com.zr.dao.showTeaDao;
import com.zr.dao.impl.showTeaDaoImpl;
import com.zr.model.grade;
import com.zr.model.student;
import com.zr.model.teacher;
import com.zr.service.showTeaService;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class showTeaServiceImpl implements showTeaService{
	showTeaDao std = new showTeaDaoImpl();
	@Override
	public JSONArray showFuncs(int parentId) {
		// TODO Auto-generated method stub
		return std.getAllByParentId(parentId);
	}
	@Override
	public String updateteacher(String tid, String tname, String tsex, String tpassword, String ttocourse,
			String ttodepartment) {
		String upd = std.updateteacherDate(tid, tname, tsex, tpassword, ttocourse, ttodepartment);
		return upd;
	}
	@Override
	public JSONObject showcmPersonMsg(int page, int size,String account) {
		int count =    std.getTeaConunt(account);
		 List<teacher>  msgs = std.getTeacherMsg(page,size,account);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}
	@Override
	public JSONObject showTeagraMsg(int page, int size,String ttodepartment,String name) {
		int count =    std.getgraConunt(ttodepartment,name);
		System.out.println("count"+count);
		 List<grade>  msgs = std.getGradeMsg(page,size,ttodepartment,name);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}
	@Override
	public String updategrade(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher, String score) {
		String upd = std.updategradeDate(gid, sid, sname, cid, cname, sclass, smajor, cteacher,score);
		return upd;
	}
	@Override
	public JSONObject showTeagraaMsg(int page, int size,String ttodepartment,String name) {
		int count =    std.getgraaConunt(ttodepartment,name);
		 List<grade>  msgs = std.getGrade1Msg(page,size,ttodepartment,name);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}
	@Override
	public String updategraade(String gid, String sid, String sname, String cid, String cname, String sclass,
			String smajor, String cteacher, String score) {
		String upd = std.updategrade1Date(gid, sid, sname, cid, cname, sclass, smajor, cteacher,score);
		return upd;
	}

}
