package com.zr.service.impl;

import java.util.List;
import com.zr.dao.ShowStugraMsgDao;
import com.zr.dao.impl.ShowStugraMsgDaoImpl;
import com.zr.model.grade;
import com.zr.service.ShowStugraMsgService;

import net.sf.json.JSONObject;

public class ShowStugraMsgServiceImpl implements ShowStugraMsgService{
	ShowStugraMsgDao ssm = new ShowStugraMsgDaoImpl();
	@Override
	public JSONObject showgradePersonMsg(int page, int size,String account) {
		 int count =    ssm.getConunt(account);
		 List<grade>  msgs = ssm.getPersonGrade(page, size,account);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}

}
