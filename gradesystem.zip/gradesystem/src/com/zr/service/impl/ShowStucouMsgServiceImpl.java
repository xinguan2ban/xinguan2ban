package com.zr.service.impl;

import java.util.List;
import com.zr.dao.ShowStucouMsgDao;
import com.zr.dao.impl.ShowStucouMsgDaoImpl;
import com.zr.model.yixuancourse;
import com.zr.service.ShowStucouMsgService;

import net.sf.json.JSONObject;

public class ShowStucouMsgServiceImpl implements ShowStucouMsgService{
	ShowStucouMsgDao ssm = new ShowStucouMsgDaoImpl();
	@Override
	public JSONObject showcmPersonMsg(int page, int size,String account) {
		 int count =    ssm.getConunt(account);
		 List<yixuancourse>  msgs = ssm.getPersoncourse(page, size,account);
		 JSONObject  js = new JSONObject();
		 js.put("total", count);
		 js.put("rows", msgs);
		 return js;
	}

}
