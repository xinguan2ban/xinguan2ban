package com.zr.service;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public interface ShowStuService {
	/**
	 * 返回datagrid要求的数据格式
	 * @param page
	 * @param size
	 * @return
	 */
	public  JSONArray  showFuncs(int parentId);
	/**
	 * 获取学生个人信息
	 * @param account
	 * @return
	 */
	public JSONObject  showcmPersonMsg(int page, int size,String account);
	/**
	 * 修改学生信息密码
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public String updatestudent(String sid, String sname,String ssex,String sclass,String smajor,String spassword);

}
