package com.zr.service;

public interface LoginService {
	
	/**
	 * 根据当前用户类型和账户返回密码
	 * @param redioname
	 * @param account
	 * @return
	 */
	public boolean validatePws(String redioname ,String account,String password);
	
	/**
	 * 根据当前用户账户返回姓名
	 * @param account
	 * @return
	 */
	public String validateNa(String redioname ,String account);
	
	/**
	 * 通过账户来验证此用户是否存在
	 * @param account
	 * @return
	 */
	public boolean validateAccount(String redioname ,String account);
	
	public String validatettodepartment(String account);
	
}
