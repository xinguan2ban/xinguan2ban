package com.zr.service;

import net.sf.json.JSONObject;

public interface ShowStucouMsgService {
	public JSONObject  showcmPersonMsg(int page, int size,String account);
}
