package com.zr.service;

import net.sf.json.JSONObject;

public interface showAdmgraMsgService {
	public JSONObject  showcmPersonMsg(int page,int size);
	//添
	public String insertgrade(String gid, String sid,String sname,String cid,String cname,String sclass,String smajor,String cteacher,String score);
	public String updategrade(String gid, String sid,String sname,String cid,String cname,String sclass,String smajor,String cteacher,String score);
	public String deletegrade(String gid);
	public boolean validateGidService(String gid);
	public JSONObject searchAdmgraMsg(String sname,String cname,String smajor);
}
