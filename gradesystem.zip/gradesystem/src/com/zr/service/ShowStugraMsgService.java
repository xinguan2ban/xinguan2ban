package com.zr.service;

import net.sf.json.JSONObject;

public interface ShowStugraMsgService {
	public JSONObject showgradePersonMsg(int page, int size,String account);
}
