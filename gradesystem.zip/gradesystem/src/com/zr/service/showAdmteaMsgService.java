package com.zr.service;

import net.sf.json.JSONObject;

public interface showAdmteaMsgService {
	public JSONObject  showcmPersonMsg(int page,int size);
	//添
	public String insertteacher(String tid, String tname,String tsex,String tpassword,String ttocourse,String ttodepartment);
	public String updateteacher(String tid, String tname,String tsex,String tpassword,String ttocourse,String ttodepartment);
	public String deleteteacher(String tid);
	public boolean validateTidService(String tid);
	public JSONObject searchAdmteaMsg(String tid,String ttocourse,String ttodepartment);
	

}
