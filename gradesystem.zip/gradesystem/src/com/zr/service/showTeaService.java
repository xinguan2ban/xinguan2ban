package com.zr.service;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public interface showTeaService {
	/**
	 * 返回datagrid要求的数据格式
	 * @param page
	 * @param size
	 * @return
	 */
	public  JSONArray  showFuncs(int parentId);
	/**
	 * 修改教师密码
	 * @param tid
	 * @param tname
	 * @param tsex
	 * @param tpassword
	 * @param ttocourse
	 * @param ttodepartment
	 * @return
	 */
	public JSONObject  showcmPersonMsg(int page, int size,String account);
	
	public String updateteacher(String tid, String tname,String tsex,String tpassword,String ttocourse,String ttodepartment);

	public JSONObject  showTeagraMsg(int page, int size,String ttodepartment,String name);
	
	public String updategrade(String gid, String sid,String sname,String cid,String cname,String sclass,String smajor,String cteacher,String score);

	public JSONObject  showTeagraaMsg(int page, int size,String ttodepartment,String name);

	public String updategraade(String gid, String sid,String sname,String cid,String cname,String sclass,String smajor,String cteacher,String score);
	
}
