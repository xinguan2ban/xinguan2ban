package com.zr.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ConnectionTool {
	 // JDBC 驱动名及数据库 URL
	private  final  static String DBURL = "jdbc:mysql://localhost:3306/gradesystem?useUnicode=true&characterEncoding=utf8";
	private  final  static String  DBDRIVER = "com.mysql.jdbc.Driver";
	// 数据库的用户名与密码，需要根据自己的设置
	private  final  static String  USERNAME = "root";
	private  final  static String  PASSWORD = "123";

	
	public static Connection getconnection(){
		Connection con = null;
		try {
			// 注册 JDBC 驱动
			Class.forName(DBDRIVER);
			con = DriverManager.getConnection(DBURL, USERNAME, PASSWORD);//驱动管理器类，getConnection（url,数据库登录名,密码）：获得连接的方法
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(Connection con,PreparedStatement pst,ResultSet rs){
		try {
			// 完成后关闭
			con.close();
			pst.close();
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}
