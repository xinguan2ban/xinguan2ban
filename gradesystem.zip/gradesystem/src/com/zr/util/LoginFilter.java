package com.zr.util;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginFilter implements Filter {
	/*
	 * init方法:容器在创建当前过滤器的时候自动调用;
	 * destroy方法:容器在销毁当前过滤器的时候自动调用
	 * doFilter方法:每次客户端请求都会调用一次。过滤器的主要代码写在这个地方
	 */
	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		//获得要用到的request，response，session对象
		HttpServletRequest servletRequest = (HttpServletRequest) request;
		HttpServletResponse servletResponse = (HttpServletResponse) response;
		HttpSession session = servletRequest.getSession();
		//获得用户请求的URI
		String path = servletRequest.getRequestURI();
		System.out.println(path);
		String account = (String) session.getAttribute("account");
		//登录页面无须过滤
		if (path.indexOf("/login.jsp") > -1 ) {
			//继续此次请求
			chain.doFilter(servletRequest, servletResponse);
            return;
		}
		 if (account == null || "".equals(account)) {
	            //跳转到登陆页面
	            servletResponse.sendRedirect("login.jsp");
	        } else {
	            //已经登陆,继续此次请求
	            chain.doFilter(request, response);
	        }
	}


	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
