function clickme(){
	var str1="1";
	var str2="2";
	var num1="parseInt(str1)";
	var num2="parseInt(str2)";
	console.debug(num1+num2);
	function chkNum(obj){
var val = obj.value;
if(val!=""){
if(!(/^[0-9]{1,20}$/.exec(val))){
obj.value="";
alert("请输入有效数字!");
obj.focus();
}
}
} 

}
